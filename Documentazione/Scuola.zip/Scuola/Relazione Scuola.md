**Autori**: Daniele Berardinell, Emanuele Bucciarelli
**Data**: 31/03/2025
## Analisi della realtà - Gestione scuola media

#### Requisiti

> Realizzare un’applicazione console in C# che interagisce con un API per ottenere e visualizzare dati relativi ai temi proposti.
> 
> Per prima cosa, creare il Modello E/R relativo al proprio argomento, poi creare il modello Logico di esso ed infine il Modello Fisico. Popolare il DB appena creato e creare le query assegnate.
> 
> Una volta sviluppato il Database, creare l’applicazione in C# che interagisce con un API, implementare le funzionalità CRUD per tutte le tabelle ipotizzate del DB e delle Query.

L'obiettivo è dunque creare un'applicazione console in C# che interagisca con le API REST, i passaggi per farlo sono:

1. Creare il modello E/R
2. Creare lo schema logico
3. Popolare il database e generare le query
4. Sviluppare l'applicazione 
5. Implementare le funzionalità CRUD (Create, Read, Update e Delete)
#### Contesto

> Si considerino i seguenti fatti di interesse di una scuola media. Insegnanti: un insegnante è identificato dal codice fiscale; di ogni insegnante interessa il cognome, il nome, le materie d'insegnamento, le classi in cui le insegna (supponiamo che un insegnante possa insegnare materie diverse in classi diverse, ad es. Italiano in una classe e Storia e Geografia in un’altra classe). Studenti: uno studente è identificato da cognome, nome, di ogni studente interessa inoltre il luogo di nascita, la data di nascita, la classe che frequenta. Classi: una classe è identificata da un numero (1, 2 o 3) e dalla sezione; di ogni classe interessa inoltre il numero di studenti che la frequentano, gli insegnanti che vi insegnano, gli studenti che la frequentano

Il progetto si concentra sulla gestione dei dati di una scuola media, includendo informazioni su insegnanti, studenti e classi

**Entità considerate:**
- Insegnante
- Studente
- Classe
- Insegnamento
#### Relazione Ternaria "Insegnamento"

La tabella `Insegnamento` rappresenta una relazione ternaria tra `Insegnante`, `Classe` e `Materia`. Questa relazione è necessaria per modellare correttamente lo scenario scolastico, in cui:

- Un **insegnante** può insegnare più materie
- Un **insegnante** può insegnare a più classi
- Una **classe** può avere più insegnanti
- Ogni insegnamento è identificato dalla combinazione insegnante-classe-materia

La chiave primaria composta `(ID_Insegnante, ID_Classe, ID_Materia)` indica che un insegnante non possa essere registrato due volte per la stessa materia nella stessa classe. Questa struttura permette di tracciare con precisione quali insegnanti insegnano quali materie e a quali classi
### Struttura delle Tabelle

#### Tabella Classe
| Nome Variabile | Tipo Dato   | NOT NULL |
| -------------- | ----------- | -------- |
| ID_Classe      | INT         | ✅        |
| numero         | TINYINT     | ✅        |
| sezione        | VARCHAR(10) | ✅        |

#### Tabella Insegnante
| Nome Variabile | Tipo Dato    | NOT NULL |
| -------------- | ------------ | -------- |
| ID_Insegnante  | INT          | ✅        |
| cod_fiscale    | VARCHAR(255) | ✅        |
| nome           | VARCHAR(255) | ✅        |
| cognome        | VARCHAR(255) | ✅        |
| data_nascita   | DATETIME     | ✅        |

#### Tabella Materia
| Nome Variabile | Tipo Dato     | NOT NULL |
|---------------|--------------|----------|
| ID_Materia   | INT          | ✅        |
| nome         | VARCHAR(255) | ✅        |

#### Tabella Studente
| Nome Variabile | Tipo Dato    | NOT NULL |
| -------------- | ------------ | -------- |
| ID_Studente    | INT          | ✅        |
| nome           | VARCHAR(255) | ✅        |
| cognome        | VARCHAR(255) | ✅        |
| data_nascita   | DATETIME     | ✅        |
| luogo_nascita  | VARCHAR(255) | ✅        |
| ID_Classe      | INT          | ✅        |

#### Tabella Insegnamento (Relazione Ternaria)
| Nome Variabile | Tipo Dato | NOT NULL |
| -------------- | --------- | -------- |
| ID_Insegnante  | INT       | ✅        |
| ID_Classe      | INT       | ✅        |
| ID_Materia     | INT       | ✅        |
### Scelte progettuali

Per la tabella Insegnante, sebbene il codice fiscale (`cod_fiscale`) sia univoco, non è stato usato come chiave primaria perché: 
- È una stringa alfanumerica, quindi meno efficiente da gestire come chiave primaria rispetto a un intero (`INT`)
- Un ID numerico garantisce prestazioni migliori in join e ricerche
- Potrebbero esistere casi in cui l'insegnante non ha ancora un codice fiscale registrato, e un ID autoincrementato semplifica la gestione

**Uso di** `TINYINT` **per il numero di classe**:
- Il numero di classe può assumere solo valori limitati (tipicamente 1, 2, 3 per la scuola media)
- `TINYINT` è più efficiente rispetto a `INT` in termini di spazio occupato nel database
- Ottimizza le prestazioni riducendo il consumo di memoria

**Utilizzo di** `**DATETIME**` **invece di** `**DateOnly**`:
- `DateOnly` è una funzionalità recente di .NET e non è supportata direttamente da molte librerie ORM, tra cui Dapper
- Dapper gestisce meglio `DATETIME` poiché è un tipo di dato standard SQL Server
- Evita conversioni manuali tra `DateOnly` e `DateTime`, riducendo il rischio di errori

> [!DATETIME] Handler
> La conversione da DateTime a DateOnly avviene nel codice attraverso un handler, spiegato successivamente

### Schema E/R

![[Pasted image 20250331090644.png]]
### Relazioni

#### 🔗 Relazione: Insegnante - Insegnamento

- Un **insegnante** può insegnare più materie in più classi (Relazione 1:N)
- Una **materia** può essere insegnata da più insegnanti in più classi
- Una **classe** può avere più insegnanti per diverse materie
- **Tabella di riferimento**: `Insegnamento` (Relazione **Ternaria** `N:N:N`)

#### 🔗 Relazione: Studente - Classe

- Uno **studente** è assegnato a una sola classe (Relazione **N:1**)
- Una **classe** può avere più studenti iscritti
- **Tabella di riferimento**: `Studente` (`ID_Classe` come FK)

#### 🔗 Relazione: Classe - Insegnante

- Una **classe** può avere più insegnanti per materie diverse (Relazione N:N attraverso `Insegnamento`)
- Un **insegnante** può insegnare a più classi
- **Tabella di riferimento**: `Insegnamento`

#### 🔗 Relazione: Classe - Materia

- Una **materia** può essere insegnata in più classi (Relazione N:N attraverso `Insegnamento`)
- Una **classe** può avere più materie assegnate
- **Tabella di riferimento**: `Insegnamento`
    
#### 🔗 Relazione: Insegnante - Materia

- Un **insegnante** può insegnare più materie (Relazione N:N attraverso `Insegnamento`)
- Una **materia** può essere insegnata da più insegnanti
- **Tabella di riferimento**: `Insegnamento`

### Schema logico

![[Pasted image 20250331091345.png]]
## Create table

Di seguito la creazione delle tabelle con SQL:
```sql
CREATE TABLE Classe
(
 ID_Classe INT PRIMARY KEY IDENTITY NOT NULL,
 numero TINYINT NOT NULL,
 sezione VARCHAR(10) NOT NULL
)

CREATE TABLE Insegnante
(
 ID_Insegnante INT PRIMARY KEY IDENTITY NOT NULL,
 cod_fiscale VARCHAR(255) NOT NULL,
 nome VARCHAR(255) NOT NULL,
 cognome VARCHAR(255) NOT NULL,
 data_nascita DATE NOT NULL
)

CREATE TABLE Materia
(
 ID_Materia INT PRIMARY KEY IDENTITY NOT NULL,
 nome VARCHAR(255) NOT NULL
)

CREATE TABLE Studente
(
 ID_Studente INT PRIMARY KEY IDENTITY NOT NULL,
 nome VARCHAR(255) NOT NULL,
 cognome VARCHAR(255) NOT NULL,
 data_nascita DATE NOT NULL,
 luogo_nascita VARCHAR(255) NOT NULL,
 ID_Classe INT NOT NULL FOREIGN KEY REFERENCES Classe(ID_Classe)
)

CREATE TABLE Insegnamento
(
 ID_Insegnante INT NOT NULL,
 ID_Classe INT NOT NULL,
 ID_Materia INT NOT NULL,
 PRIMARY KEY (ID_Insegnante, ID_Classe, ID_Materia),
 FOREIGN KEY (ID_Insegnante) REFERENCES Insegnante(ID_Insegnante),
 FOREIGN KEY (ID_Classe) REFERENCES Classe(ID_Classe),
 FOREIGN KEY (ID_Materia) REFERENCES Materia(ID_Materia)
)
```

## Popolamento

```sql
-- inserimento per le classi
INSERT INTO Classe (numero, sezione) VALUES (1, 'A');
INSERT INTO Classe (numero, sezione) VALUES (2, 'B');

-- inserimento per gli insegnanti
INSERT INTO Insegnante (cod_fiscale, nome, cognome, data_nascita) VALUES 
('MRCMRC06M26I608Q', 'Marco', 'Mudric', '2006-08-26'),
('BRRDNL06E24I608Y', 'Daniele', 'Berardinelli', '2006-05-24');

-- inserimento di materie 
INSERT INTO Materia (nome) VALUES ('Matematica');
INSERT INTO Materia (nome) VALUES ('Informatica');
INSERT INTO Materia (nome) VALUES ('Italiano');

-- inserimento di studenti
INSERT INTO Studente (nome, cognome, data_nascita, luogo_nascita, ID_Classe) VALUES 
('Giampaolo', 'Magi', '2006-09-15', 'Fano', 1),
('Claudio', 'Lenci', '2006-05-24', 'Senigallia', 1),
('Giacomo', 'Principi', '2006-11-05', 'Montesicuro', 2);

-- la relazione ternaria
INSERT INTO Insegnamento (ID_Insegnante, ID_Classe, ID_Materia) VALUES 
(1, 1, 1), -- Marco Mudric insegna matematica alla classe 1A
(1, 1, 3), -- Marco Mudric insegna italiano alla classe 1A
(2, 2, 2), -- Daniele Berardinelli insegna informatica alla classe 2B
(2, 1, 2); -- Daniele Berardinelli insegna informatica anche alla classe 1A

```

## Query

Query 1

> Recuperare tutti gli studenti che frequentano una specifica classe, identificata dal numero e dalla sezione.

```sql
SELECT * FROM Studente
INNER JOIN Classe ON Studente.ID_Classe = Classe.ID_Classe
WHERE Classe.numero = X AND Classe.sezione = 'Y'; -- ovviamente X è il numero della classe e 'Y' fa riferimento alla sezione, questa è una generalizzazione che nel programma vengono inseriti dall'utente
```

**Spiegazione**:
- Cerca nella tabella `Studente` e combina (`INNER JOIN`) con `Classe` tramite l'ID della classe
- Filtra (`WHERE`) per:
    - `numero` (es. 1 per prima, 2 per seconda...)
    - `sezione` (es. 'A', 'B'...)        
- Restituisce tutti i campi (`*`) degli studenti corrispondenti

Query 2

> Elencare tutti gli insegnanti che insegnano in una determinata classe.

```sql
SELECT DISTINCT * FROM Insegnante
INNER JOIN Insegnamento ON Insegnante.ID_Insegnante = Insegnamento.ID_Insegnante
WHERE Insegnamento.ID_Classe = (SELECT ID_Classe FROM Classe WHERE numero = x and sezione = 'Y');
```

**Spiegazione**:
1. Prima trova l'ID della classe con una sottoquery
2. Poi cerca nella tabella `Insegnamento` gli insegnanti associati a quell'ID
3. `DISTINCT` evita duplicati se un insegnante ha più materie nella stessa classe
4. Combina con i dati completi degli insegnanti


Query 3

> Trovare tutte le materie insegnate da un determinato insegnante e le classi in cui le insegna.

```sql
SELECT Materia.nome AS materia, Classe.numero, Classe.sezione
FROM Insegnamento
JOIN Materia ON Insegnamento.ID_Materia = Materia.ID_Materia
JOIN Classe ON Insegnamento.ID_Classe = Classe.ID_Classe
WHERE Insegnamento.ID_Insegnante = 1;
```

**Spiegazione**:
- Parte dall'ID insegnante (es. 1)
- Combina tre tabelle per ottenere:
    - Nome materia (da `Materia`)
    - Numero e sezione classe (da `Classe`)
- Restituisce solo le colonne specificate

Query 4

> Individuare il numero totale di studenti per ciascuna classe, ordinando il risultato in ordine decrescente.

```sql
SELECT Classe.numero, Classe.sezione, COUNT(Studente.ID_Studente) AS num_studenti FROM Classe
LEFT JOIN Studente ON Classe.ID_Classe = Studente.ID_Classe
GROUP BY Classe.ID_Classe,Classe.numero, Classe.sezione
ORDER BY num_studenti DESC;
```

**Spiegazione**:
- `LEFT JOIN` include anche classi senza studenti
- `COUNT` calcola il numero di studenti per classe
- `GROUP BY` raggruppa per classe
- `ORDER BY DESC` ordina dalla classe più numerosa


Query 5

> Contare quanti insegnanti insegnano in più di una classe e restituire il numero totale di classi in cui ognuno insegna.

```sql
SELECT Insegnante.cod_fiscale, Insegnante.nome, Insegnante.cognome, COUNT(DISTINCT Insegnamento.ID_Classe) AS num_classi
FROM Insegnante
INNER JOIN Insegnamento ON Insegnante.ID_Insegnante = Insegnamento.ID_Insegnante
GROUP BY Insegnante.ID_Insegnante, Insegnante.cod_fiscale, Insegnante.nome, Insegnante.cognome
HAVING COUNT(DISTINCT Insegnamento.ID_Classe) > 1;
```

**Spiegazione**:
- `COUNT(DISTINCT ...)` conta classi diverse (ignorando duplicati)
- `HAVING` filtra solo chi ha >1 classe
- Restituisce CF, nome completo e numero classi

## Documentazione del codice

